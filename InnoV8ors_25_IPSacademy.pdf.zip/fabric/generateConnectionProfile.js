const fs = require("fs");
const path = require("path");

const FABRIC_SAMPLES = "C:\\Users\\DELL\\Desktop\\fabric-samples";
const TEST_NETWORK = path.join(FABRIC_SAMPLES, "test-network");
const ORG1_PATH = path.join(
  TEST_NETWORK,
  "organizations",
  "peerOrganizations",
  "org1.example.com"
);

function readCert(certPath) {
  try {
    return fs.readFileSync(certPath, "utf8");
  } catch (error) {
    console.error(`Error reading ${certPath}:`, error.message);
    return null;
  }
}

// Read certificates
const peerTlsCertPath = path.join(
  ORG1_PATH,
  "peers",
  "peer0.org1.example.com",
  "tls",
  "ca.crt"
);
const caTlsCertPath = path.join(
  ORG1_PATH,
  "ca",
  "ca.org1.example.com-cert.pem"
);

const peerTlsCert = readCert(peerTlsCertPath);
const caTlsCert = readCert(caTlsCertPath);

if (!peerTlsCert || !caTlsCert) {
  console.error(
    "Failed to read certificates. Make sure Fabric network is running!"
  );
  console.error(
    "Start network: cd fabric-samples\\test-network && .\\network.sh up createChannel -ca"
  );
  process.exit(1);
}

const connectionProfile = {
  name: "test-network-org1",
  version: "1.0.0",
  client: {
    organization: "Org1",
    connection: {
      timeout: {
        peer: { endorser: "300" },
        orderer: "300",
      },
    },
  },
  organizations: {
    Org1: {
      mspid: "Org1MSP",
      peers: ["peer0.org1.example.com"],
      certificateAuthorities: ["ca.org1.example.com"],
    },
  },
  peers: {
    "peer0.org1.example.com": {
      url: "grpcs://localhost:7051",
      tlsCACerts: {
        pem: peerTlsCert,
      },
      grpcOptions: {
        "ssl-target-name-override": "peer0.org1.example.com",
        hostnameOverride: "peer0.org1.example.com",
      },
    },
  },
  certificateAuthorities: {
    "ca.org1.example.com": {
      url: "https://localhost:7054",
      caName: "ca-org1",
      tlsCACerts: {
        pem: caTlsCert,
      },
      httpOptions: {
        verify: false,
      },
    },
  },
};

// Write file
const outputPath = path.join(__dirname, "connection-org1.json");
fs.writeFileSync(outputPath, JSON.stringify(connectionProfile, null, 2));

console.log("✓ Connection profile generated successfully!");
console.log(`  Location: ${outputPath}`);
