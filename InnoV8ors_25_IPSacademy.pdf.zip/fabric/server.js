// // server.js - Express API Server for Hyperledger Fabric
// const express = require("express");
// const { Gateway, Wallets } = require("fabric-network");
// const path = require("path");
// const fs = require("fs");

// const app = express();
// app.use(express.json());

// // Configuration
// const channelName = "mychannel";
// const chaincodeName = "basic";
// const mspOrg1 = "Org1MSP";
// const walletPath = path.join(__dirname, "wallet");
// const ccpPath = path.join(__dirname, "connection-org1.json");

// // Initialize connection to Fabric network
// async function connectToNetwork(userId) {
//   const ccp = JSON.parse(fs.readFileSync(ccpPath, "utf8"));
//   const wallet = await Wallets.newFileSystemWallet(walletPath);

//   const identity = await wallet.get(userId);
//   if (!identity) {
//     throw new Error(`Identity ${userId} does not exist in the wallet`);
//   }

//   const gateway = new Gateway();
//   await gateway.connect(ccp, {
//     wallet,
//     identity: userId,
//     discovery: { enabled: true, asLocalhost: true },
//   });

//   const network = await gateway.getNetwork(channelName);
//   const contract = network.getContract(chaincodeName);

//   return { gateway, contract };
// }

// // POST API - Create/Update asset
// app.post("/api/asset", async (req, res) => {
//   try {
//     const { id, color, size, owner, value } = req.body;

//     if (!id || !color || !size || !owner || !value) {
//       return res.status(400).json({ error: "Missing required fields" });
//     }

//     const { gateway, contract } = await connectToNetwork("appUser");

//     // Submit transaction
//     await contract.submitTransaction(
//       "CreateAsset",
//       id,
//       color,
//       size,
//       owner,
//       value
//     );

//     await gateway.disconnect();

//     res.status(201).json({
//       success: true,
//       message: "Asset created successfully",
//       data: { id, color, size, owner, value },
//     });
//   } catch (error) {
//     console.error("Error:", error);
//     res.status(500).json({ error: error.message });
//   }
// });

// // GET API - Read single asset
// app.get("/api/asset/:id", async (req, res) => {
//   try {
//     const assetId = req.params.id;

//     const { gateway, contract } = await connectToNetwork("appUser");

//     // Evaluate transaction (query)
//     const result = await contract.evaluateTransaction("ReadAsset", assetId);

//     await gateway.disconnect();

//     const asset = JSON.parse(result.toString());
//     res.status(200).json({
//       success: true,
//       data: asset,
//     });
//   } catch (error) {
//     console.error("Error:", error);
//     res.status(500).json({ error: error.message });
//   }
// });

// // GET API - Read all assets
// app.get("/api/assets", async (req, res) => {
//   try {
//     const { gateway, contract } = await connectToNetwork("appUser");

//     // Evaluate transaction (query)
//     const result = await contract.evaluateTransaction("GetAllAssets");

//     await gateway.disconnect();

//     const assets = JSON.parse(result.toString());
//     res.status(200).json({
//       success: true,
//       data: assets,
//     });
//   } catch (error) {
//     console.error("Error:", error);
//     res.status(500).json({ error: error.message });
//   }
// });

// // PUT API - Update asset owner
// app.put("/api/asset/:id", async (req, res) => {
//   try {
//     const assetId = req.params.id;
//     const { owner } = req.body;

//     if (!owner) {
//       return res.status(400).json({ error: "Owner field is required" });
//     }

//     const { gateway, contract } = await connectToNetwork("appUser");

//     await contract.submitTransaction("TransferAsset", assetId, owner);

//     await gateway.disconnect();

//     res.status(200).json({
//       success: true,
//       message: "Asset updated successfully",
//     });
//   } catch (error) {
//     console.error("Error:", error);
//     res.status(500).json({ error: error.message });
//   }
// });

// // DELETE API - Delete asset
// app.delete("/api/asset/:id", async (req, res) => {
//   try {
//     const assetId = req.params.id;

//     const { gateway, contract } = await connectToNetwork("appUser");

//     await contract.submitTransaction("DeleteAsset", assetId);

//     await gateway.disconnect();

//     res.status(200).json({
//       success: true,
//       message: "Asset deleted successfully",
//     });
//   } catch (error) {
//     console.error("Error:", error);
//     res.status(500).json({ error: error.message });
//   }
// });

// // Health check
// app.get("/health", (req, res) => {
//   res.json({ status: "Server is running" });
// });

// const PORT = process.env.PORT || 3000;
// app.listen(PORT, () => {
//   console.log(`Server running on port ${PORT}`);
// });

const express = require("express");
const { Gateway, Wallets } = require("fabric-network");
const path = require("path");
const fs = require("fs");
const cors = require("cors");

const app = express();
app.use(express.json());
app.use(cors());

// Configuration
const channelName = "mychannel";
const chaincodeName = "metrotrain"; // Change this to your deployed chaincode name
const mspOrg1 = "Org1MSP";
const walletPath = path.join(__dirname, "wallet");
const ccpPath = path.join(__dirname, "connection-org1.json");

// Initialize connection to Fabric network
async function connectToNetwork(userId) {
  const ccp = JSON.parse(fs.readFileSync(ccpPath, "utf8"));
  const wallet = await Wallets.newFileSystemWallet(walletPath);

  const identity = await wallet.get(userId);
  if (!identity) {
    throw new Error(`Identity ${userId} does not exist in the wallet`);
  }

  const gateway = new Gateway();
  await gateway.connect(ccp, {
    wallet,
    identity: userId,
    discovery: { enabled: true, asLocalhost: true },
  });

  const network = await gateway.getNetwork(channelName);
  const contract = network.getContract(chaincodeName);

  return { gateway, contract };
}

// ==================== METRO TRAIN ENDPOINTS ====================

// Health check
app.get("/health", (req, res) => {
  res.json({
    status: "Metro Train Management API is running",
    timestamp: new Date().toISOString(),
  });
});

// POST API - Create daily train record
app.post("/api/metro/daily-record", async (req, res) => {
  try {
    const trainData = req.body;

    if (!trainData.date) {
      return res.status(400).json({
        success: false,
        error: "Date field is required",
      });
    }

    const { gateway, contract } = await connectToNetwork("appUser");

    // Submit transaction to blockchain
    const result = await contract.submitTransaction(
      "CreateTrainRecord",
      JSON.stringify(trainData)
    );

    await gateway.disconnect();

    const response = JSON.parse(result.toString());

    res.status(201).json({
      success: true,
      message: "Train record created on blockchain",
      recordKey: response.recordKey,
      date: trainData.date,
    });
  } catch (error) {
    console.error("Error creating train record:", error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// GET API - Read single record by key
app.get("/api/metro/record/:recordKey", async (req, res) => {
  try {
    const recordKey = req.params.recordKey;

    const { gateway, contract } = await connectToNetwork("appUser");

    const result = await contract.evaluateTransaction(
      "ReadTrainRecord",
      recordKey
    );

    await gateway.disconnect();

    const record = JSON.parse(result.toString());
    res.status(200).json({
      success: true,
      data: record,
    });
  } catch (error) {
    console.error("Error reading record:", error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// GET API - Get all train records
app.get("/api/metro/all-records", async (req, res) => {
  try {
    const { gateway, contract } = await connectToNetwork("appUser");

    const result = await contract.evaluateTransaction("GetAllTrainRecords");

    await gateway.disconnect();

    const records = JSON.parse(result.toString());
    res.status(200).json({
      success: true,
      count: records.length,
      data: records,
    });
  } catch (error) {
    console.error("Error getting all records:", error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// GET API - Get records by date
app.get("/api/metro/records/date/:date", async (req, res) => {
  try {
    const date = req.params.date;

    const { gateway, contract } = await connectToNetwork("appUser");

    const result = await contract.evaluateTransaction("GetRecordsByDate", date);

    await gateway.disconnect();

    const records = JSON.parse(result.toString());
    res.status(200).json({
      success: true,
      date: date,
      count: records.length,
      data: records,
    });
  } catch (error) {
    console.error("Error getting records by date:", error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// GET API - Get all data for specific train
app.get("/api/metro/train/:trainId", async (req, res) => {
  try {
    const trainId = req.params.trainId;

    const { gateway, contract } = await connectToNetwork("appUser");

    const result = await contract.evaluateTransaction("GetTrainData", trainId);

    await gateway.disconnect();

    const records = JSON.parse(result.toString());
    res.status(200).json({
      success: true,
      trainId: trainId,
      recordCount: records.length,
      data: records,
    });
  } catch (error) {
    console.error("Error getting train data:", error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// GET API - Get mileage history for train
app.get("/api/metro/train/:trainId/mileage", async (req, res) => {
  try {
    const trainId = req.params.trainId;

    const { gateway, contract } = await connectToNetwork("appUser");

    const result = await contract.evaluateTransaction(
      "GetTrainMileageHistory",
      trainId
    );

    await gateway.disconnect();

    const mileageHistory = JSON.parse(result.toString());
    res.status(200).json({
      success: true,
      trainId: trainId,
      mileageRecords: mileageHistory.length,
      data: mileageHistory,
    });
  } catch (error) {
    console.error("Error getting mileage history:", error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// GET API - Get fitness certificate history for train
app.get("/api/metro/train/:trainId/fitness", async (req, res) => {
  try {
    const trainId = req.params.trainId;

    const { gateway, contract } = await connectToNetwork("appUser");

    const result = await contract.evaluateTransaction(
      "GetTrainFitnessHistory",
      trainId
    );

    await gateway.disconnect();

    const fitnessHistory = JSON.parse(result.toString());
    res.status(200).json({
      success: true,
      trainId: trainId,
      fitnessRecords: fitnessHistory.length,
      data: fitnessHistory,
    });
  } catch (error) {
    console.error("Error getting fitness history:", error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// PUT API - Update train record
app.put("/api/metro/record/:recordKey", async (req, res) => {
  try {
    const recordKey = req.params.recordKey;
    const trainData = req.body;

    if (!trainData.date) {
      return res.status(400).json({
        success: false,
        error: "Date field is required",
      });
    }

    const { gateway, contract } = await connectToNetwork("appUser");

    await contract.submitTransaction(
      "UpdateTrainRecord",
      recordKey,
      JSON.stringify(trainData)
    );

    await gateway.disconnect();

    res.status(200).json({
      success: true,
      message: "Record updated successfully on blockchain",
      recordKey: recordKey,
    });
  } catch (error) {
    console.error("Error updating record:", error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// DELETE API - Delete train record
app.delete("/api/metro/record/:recordKey", async (req, res) => {
  try {
    const recordKey = req.params.recordKey;

    const { gateway, contract } = await connectToNetwork("appUser");

    await contract.submitTransaction("DeleteTrainRecord", recordKey);

    await gateway.disconnect();

    res.status(200).json({
      success: true,
      message: "Record deleted successfully from blockchain",
      recordKey: recordKey,
    });
  } catch (error) {
    console.error("Error deleting record:", error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// GET API - Get audit trail/history for a record
app.get("/api/metro/history/:recordKey", async (req, res) => {
  try {
    const recordKey = req.params.recordKey;

    const { gateway, contract } = await connectToNetwork("appUser");

    const result = await contract.evaluateTransaction(
      "GetRecordHistory",
      recordKey
    );

    await gateway.disconnect();

    const history = JSON.parse(result.toString());
    res.status(200).json({
      success: true,
      recordKey: recordKey,
      historyCount: history.length,
      history: history,
    });
  } catch (error) {
    console.error("Error getting record history:", error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== OLD ASSET ENDPOINTS (Keep for backward compatibility) ====================

// POST API - Create/Update asset (OLD - for testing)
app.post("/api/asset", async (req, res) => {
  try {
    const { id, color, size, owner, value } = req.body;

    if (!id || !color || !size || !owner || !value) {
      return res.status(400).json({ error: "Missing required fields" });
    }

    const { gateway, contract } = await connectToNetwork("appUser");

    // Submit transaction
    await contract.submitTransaction(
      "CreateAsset",
      id,
      color,
      size,
      owner,
      value
    );

    await gateway.disconnect();

    res.status(201).json({
      success: true,
      message: "Asset created successfully",
      data: { id, color, size, owner, value },
    });
  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ error: error.message });
  }
});

// GET API - Read single asset (OLD)
app.get("/api/asset/:id", async (req, res) => {
  try {
    const assetId = req.params.id;

    const { gateway, contract } = await connectToNetwork("appUser");

    const result = await contract.evaluateTransaction("ReadAsset", assetId);

    await gateway.disconnect();

    const asset = JSON.parse(result.toString());
    res.status(200).json({
      success: true,
      data: asset,
    });
  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ error: error.message });
  }
});

// GET API - Read all assets (OLD)
app.get("/api/assets", async (req, res) => {
  try {
    const { gateway, contract } = await connectToNetwork("appUser");

    const result = await contract.evaluateTransaction("GetAllAssets");

    await gateway.disconnect();

    const assets = JSON.parse(result.toString());
    res.status(200).json({
      success: true,
      data: assets,
    });
  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ error: error.message });
  }
});

// PUT API - Update asset owner (OLD)
app.put("/api/asset/:id", async (req, res) => {
  try {
    const assetId = req.params.id;
    const { owner } = req.body;

    if (!owner) {
      return res.status(400).json({ error: "Owner field is required" });
    }

    const { gateway, contract } = await connectToNetwork("appUser");

    await contract.submitTransaction("TransferAsset", assetId, owner);

    await gateway.disconnect();

    res.status(200).json({
      success: true,
      message: "Asset updated successfully",
    });
  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ error: error.message });
  }
});

// DELETE API - Delete asset (OLD)
app.delete("/api/asset/:id", async (req, res) => {
  try {
    const assetId = req.params.id;

    const { gateway, contract } = await connectToNetwork("appUser");

    await contract.submitTransaction("DeleteAsset", assetId);

    await gateway.disconnect();

    res.status(200).json({
      success: true,
      message: "Asset deleted successfully",
    });
  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ error: error.message });
  }
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log("=".repeat(60));
  console.log("🚇 Metro Train Management API Server");
  console.log("=".repeat(60));
  console.log(`✓ Server running on port ${PORT}`);
  console.log(`✓ Health check: http://localhost:${PORT}/health`);
  console.log("=".repeat(60));
  console.log("\n📋 Metro Train Endpoints:");
  console.log(`  POST   /api/metro/daily-record`);
  console.log(`  GET    /api/metro/all-records`);
  console.log(`  GET    /api/metro/record/:recordKey`);
  console.log(`  GET    /api/metro/records/date/:date`);
  console.log(`  GET    /api/metro/train/:trainId`);
  console.log(`  GET    /api/metro/train/:trainId/mileage`);
  console.log(`  GET    /api/metro/train/:trainId/fitness`);
  console.log(`  PUT    /api/metro/record/:recordKey`);
  console.log(`  DELETE /api/metro/record/:recordKey`);
  console.log(`  GET    /api/metro/history/:recordKey`);
  console.log("=".repeat(60));
});
