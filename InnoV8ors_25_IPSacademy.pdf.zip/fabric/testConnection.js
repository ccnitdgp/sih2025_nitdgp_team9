const { Gateway, Wallets } = require("fabric-network");
const fs = require("fs");
const path = require("path");

async function test() {
  try {
    const ccpPath = path.resolve(__dirname, "connection-org1.json");
    const ccp = JSON.parse(fs.readFileSync(ccpPath, "utf8"));

    console.log("✓ Connection profile loaded successfully");
    console.log("  Peers:", Object.keys(ccp.peers));
    console.log("  CAs:", Object.keys(ccp.certificateAuthorities));
  } catch (error) {
    console.error("✗ Error:", error.message);
  }
}

test();
